//
//  SearchResultTableViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/4/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
import FirebaseStorage

var imageAD = ""
var imageAD1 = ""
var imageAD2 = ""
var imageAD3 = ""
var breedAD = ""
var colorAD = ""
var ageAD = ""
var genderAD = ""
var nameAD = ""
var regionAD = ""
var cityAD = ""
var descriptionAD = ""
var nameOwnerAD = ""
var numberOwnerAD = ""


class SearchResultTableViewController: UITableViewController {
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*Database.database().reference(withPath: "publications").observe(.value, with: { (snapshot) -> Void in
            var newAnimals = [Animal]()
            for child in snapshot.children { 
                
                if let snapshot = child as? DataSnapshot{
                    
                    if  let animal = Animal(snapshot: snapshot){
                    print("snapshot \(snapshot)")
                    print("animal \(animal)")
                    newAnimals.append(animal)
                    }
                    else {
                        print("not animal")
                    }
                }
                else {
                    print("not snapshot")
                }
            }
            
            animalsArray = newAnimals
            print(animalsArray)
            self.tableView.reloadData()
        })*/
        
        
        
        Database.database().reference().child("publications").queryOrdered(byChild: "Animal").queryEqual(toValue: selectedTypeForResult).observeSingleEvent(of: .value, with: { (snapshot) -> Void in
            
            var newAnimals = [Animal]()
            for child in snapshot.children { // children of "publications"
               
                if let snapshot = child as? DataSnapshot {
                    
                    if  let animal = Animal(snapshot: snapshot) {
                        
                        
                        
                        if animal.gender == selectedGenderForReult {
                            
                            //print(self.myReturn(str: "userCity", userCU: String(animal.currentUser)))
                            
                            if buttonOn == true{
                                
                                
                                if selectedBreedForResult != "" && selectedColorForResult != ""  {
                                    if animal.breed == selectedBreedForResult && animal.color == selectedColorForResult {
                                        newAnimals.append(animal)
                                    }
                                }
                                
                                
                                
                                
                                else if selectedBreedForResult != "" {
                                    if animal.breed == selectedBreedForResult {
                                        newAnimals.append(animal)
                                    }
                                }
                                
                                
                                else if selectedColorForResult != "" {
                                    if animal.color == selectedColorForResult {
                                        newAnimals.append(animal)
                                    }
                                }
                                
                                else  if selectedColorForResult == "" && selectedBreedForResult == "" {
                                    newAnimals.append(animal)
                                }
                                
                                
                            }
                            
                            
                            /* else if buttonOn == false {
                                
                                
                                if  selectedCityForResult != "" && selectedRegionForResult == "" && selectedBreedForResult == "" && selectedColorForResult == "" { // все фильтры поставлены
                                    if selectedCityForResult == self.myReturn(filter: "userCity",userId: String(animal.currentUser)) {
                                        newAnimals.append(animal)
                                    }
                                }
                                */
                                //заполнили все4
                                /*   if selectedBreedForResult != "" && selectedColorForResult != "" && selectedRegionForResult != "" && selectedCityForResult != "" { // все фильтры поставлены
                                    if animal.breed == selectedBreedForResult && animal.color == selectedColorForResult && selectedRegionForResult == self.myReturn(str: "userArea", userCU: String(animal.currentUser)) &&
                                        selectedCityForResult == self.myReturn(str: "userCity", userCU: String(animal.currentUser)){
                                        newAnimals.append(animal)
                                    }
                                }
                                
                                //не заполнили город
                                else if selectedBreedForResult != "" && selectedColorForResult != "" && selectedRegionForResult != ""{
                                    
                                    if animal.breed == selectedBreedForResult && animal.color == selectedColorForResult && selectedRegionForResult == self.myReturn(str: "userArea", userCU: String(animal.currentUser)) {
                                        newAnimals.append(animal)
                                    }
                                    
                                }
                                
                                
                                
                                //не заполнили область
                                else if selectedBreedForResult != "" && selectedColorForResult != "" && selectedCityForResult != "" {
                                     print(self.myReturn(str: "userCity", userCU: String(animal.currentUser)))
                                    if animal.breed == selectedBreedForResult && animal.color == selectedColorForResult &&
                                        selectedCityForResult == self.myReturn(str: "userCity", userCU: String(animal.currentUser)){
                                        newAnimals.append(animal)
                                    }
                                    
                                    
                                }
                                
                                */
                                
                          //  }
 
                           
                            
                            
                        
                            
                            
                        }else {
                            print("trouble with gender")
                        }
                       
                    }
                    else {
                        print("not animal")
                    }
                }
                else {
                    print("not snapshot")
                }
            }
            
            animalsArray = newAnimals
            print(animalsArray)
            self.tableView.reloadData()
        })
    }
    
  
//refU.child(String(animal.currentUser)
    /* func myReturn(str:String,userCU:String)->String{
        var res = ""
        let refU = Database.database().reference(withPath: "users")
        refU.child(userCU).observeSingleEvent(of:.value) {
                (snapshot) in
            
               if snapshot.exists(){
                   // print(snapshot)
                    let dict = snapshot.value as! [String:Any]
                    print(dict)
                    //dict["userCity"]
                    res = dict[str] as! String
                    print(res)
                    
                    
                }
                else {
                    print("noooooo")
            }
        }
       print(res)
        
         return res
    }*/
    
 
    
    /* func myReturn(filter: String, userId: String) -> String {
        let refU = Database.database().reference(withPath: "users")
        var result:String!
        refU.child(userId).observeSingleEvent(of:.value) {
            (snapshot) in
            
            if snapshot.exists() {
                let dict = snapshot.value as! [String:Any]
                print(dict)
                result = dict[filter] as! String
                
            } else {
                print("noooooo")
            }
        }
        return result
    }
    */
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return animalsArray.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as! SearchTableViewCell
        cell.layer.borderWidth = 0.5
        let borderColor: UIColor = .black
        cell.layer.borderColor = borderColor.cgColor
        
        cell.set(animal:animalsArray[indexPath.row])
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       
        nameAD = animalsArray[indexPath.row].name
        breedAD =  animalsArray[indexPath.row].breed
        ageAD = animalsArray[indexPath.row].age
        //cityAD = cityOfUserIn as! String
        colorAD = animalsArray[indexPath.row].color
        descriptionAD = animalsArray[indexPath.row].description
        genderAD = animalsArray[indexPath.row].gender
        imageAD = animalsArray[indexPath.row].imageAnimal0
        imageAD1 = animalsArray[indexPath.row].imageAnimal1
        imageAD2 = animalsArray[indexPath.row].imageAnimal2
        imageAD3 = animalsArray[indexPath.row].imageAnimal3
       // regionAD = areaOfUserIn as! String
       
       
    }
    

    @IBAction func backToTabBar(_ sender: UIBarButtonItem) {
        let pvc = self.storyboard?.instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
        self.present(pvc, animated: false, completion: nil)
    }
    
}
