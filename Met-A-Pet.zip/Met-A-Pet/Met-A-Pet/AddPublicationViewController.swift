//
//  AddPublicationViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/8/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
import FirebaseStorage

class AddPublicationViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextFieldDelegate,UITextViewDelegate,UIDocumentPickerDelegate, UIPickerViewDelegate ,UIPickerViewDataSource{

    @IBOutlet weak var genderOutletSC: UISegmentedControl!
    @IBOutlet weak var typeAnimalOutletSC: UISegmentedControl!
    @IBOutlet weak var nameOfAnimal: UITextField!
    @IBOutlet weak var breedOfAnimal: UITextField!
    @IBOutlet weak var colorOfAnimal: UITextField!
    @IBOutlet weak var ageOfAnimal: UITextField!
    @IBOutlet weak var descriptionOfAnimal: UITextView!
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView4: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var addImageButton4: UIButton!
    @IBOutlet weak var addImageButton3: UIButton!
    @IBOutlet weak var addImageButton2: UIButton!
    @IBOutlet weak var addImageButton1: UIButton!
    
    var cityCurrentUser:String = ""
    var regionCurrentuser:String = ""
    var refUsers:DatabaseReference?
    //var ref:DatabaseReference?
    var typeAnimalString:String = ""
    var genderAnimalString:String = ""
    var images:[String] = []
    
    var selectedTypeAnimal = 0
    var selectedGenderAnimal = 0
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        breedOfAnimal.inputView = thePicker
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(self.doneClick))
        let cancelButton = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(self.cancelClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        breedOfAnimal.inputAccessoryView = toolBar
        
        //окрасы
        colorOfAnimal.inputView = thePickerColor
        let toolBar1 = UIToolbar()
        toolBar1.barStyle = .default
        toolBar1.sizeToFit()
        let doneButton1 = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(self.doneClick1))
        let cancelButton1 = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(self.cancelClick1))
        let spaceButton1 = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar1.setItems([cancelButton1, spaceButton1, doneButton1], animated: false)
        colorOfAnimal.inputAccessoryView = toolBar1
        
        //let myColor = UIColor.init(red: 0.0, green: 122.0/255.0, blue: 1.0 , alpha: 1.0)
        //breedOfAnimal.layer.borderColor = myColor.cgColor
        //colorOfAnimal.layer.borderColor = myColor.cgColor
        breedOfAnimal.layer.borderWidth = 1.0
        colorOfAnimal.layer.borderWidth = 1.0
        breedOfAnimal.delegate = self
        colorOfAnimal.delegate = self
        
        let font = UIFont.systemFont(ofSize: 20)
        typeAnimalOutletSC.setTitleTextAttributes([NSAttributedString.Key.font: font], for: .normal)
        genderOutletSC.setTitleTextAttributes([NSAttributedString.Key.font: font], for: .normal)
        breedOfAnimal.attributedPlaceholder = NSAttributedString(string: "Выберите породу",
                                                                attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        colorOfAnimal.attributedPlaceholder = NSAttributedString(string: "Выберите окрас",
                                                                 attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        ageOfAnimal.attributedPlaceholder = NSAttributedString(string: "Возраст",
                                                               attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        nameOfAnimal.attributedPlaceholder = NSAttributedString(string: "Кличка",
                                                                attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
       /* descriptionOfAnimal.attributedText =  NSAttributedString(string: "Описание",
                                                                 attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])*/
       
        
        breedOfAnimal.delegate = self
        colorOfAnimal.delegate = self

        
        thePicker.tag = 0
        thePickerColor.tag = 1
       
        thePicker.delegate = self
        thePickerColor.delegate = self
        
        
        
        
        Database.database().reference(withPath: "publications").observe(.value, with: { (snapshot) -> Void in
     print("child added")
            
            var newAnimals = [Animal]()
            for child in snapshot.children { // children of "publications"
                print(child)
                
                if let snapshot = child as? DataSnapshot,
                    let animal = Animal(snapshot: snapshot) {
                    newAnimals.append(animal)
                } else {
                    print("can not initialize")
                }
            }
            animalsArray = newAnimals
              print("animalsArrayCount \(animalsArray.count)")
            //SearchResultTableViewController.tableView.reloadData()
        })
        
  
        
        nameOfAnimal.delegate = self
        breedOfAnimal.delegate = self
        colorOfAnimal.delegate = self
        ageOfAnimal.delegate = self
        descriptionOfAnimal.delegate = self

        let fontt = UIFont.systemFont(ofSize: 20)
    typeAnimalOutletSC.setTitleTextAttributes([NSAttributedString.Key.font: fontt], for: .normal)
        genderOutletSC.setTitleTextAttributes([NSAttributedString.Key.font: fontt], for: .normal)
        
        imagePicker.delegate = self
        ////извлекаем город и регион пользователя, который добавляет публикацию
       // storageRef = Storage.storage().reference(withPath: "all-images")
      /*  refUsers = Database.database().reference(withPath: "users")
        ref = Database.database().reference(withPath: "publications")
        refUsers?.child(userID).observeSingleEvent(of: .value, with: {(snapshot) in
            //var region = (snapshot.value as! NSDictionary)["region"] as! String
            //var city = (snapshot.value as! NSDictionary)["city"] as! String
            //self.regionCurrentuser = region
            //self.cityCurrentUser = city
            //print(region,city)
        })*/
        
        
    }
    
    @IBAction func selectGenderAnimal(_ sender: UISegmentedControl) {
        selectedGenderAnimal = genderOutletSC.selectedSegmentIndex
        
    }
    @IBAction func selectTypeAnimalAction(_ sender: UISegmentedControl) {
        selectedTypeAnimal = sender.selectedSegmentIndex
        
    }
    let thePicker = UIPickerView() // для пород
    let thePickerColor = UIPickerView() // для окрасов
   
    
    @objc func doneClick() {
        
        let indexPath = thePicker.selectedRow(inComponent: 0)
        
        breedOfAnimal.text = selectedTypeAnimal == 0 ? breedDataDog[indexPath] : breedDataCat[indexPath]
        self.view.endEditing(true)
        
        
        
    }
    @objc func cancelClick() {
        print("fuck")
        breedOfAnimal.text = ""
        //colorVariants.text = ""
        self.view.endEditing(true)
    }
    @objc func doneClick1() {
        
        let indexPath = thePickerColor.selectedRow(inComponent: 0)
        //let resultArray =  selectedTypeAnimal == 0 ? colorDog : colorCat
        colorOfAnimal.text = color[indexPath]
        self.view.endEditing(true)
        
        
    }
    @objc func cancelClick1() {
        colorOfAnimal.text = ""
        self.view.endEditing(true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag {
        case 0:
            var result = selectedTypeAnimal == 0 ? breedDataDog.count : breedDataCat.count
            return result
        case 1:
            
            var result = color.count
            return result
       
        default:
            break
        }
        return 0
    }
    
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        switch pickerView.tag {
        case 0:
            var result:String
            if selectedTypeAnimal == 0 {
                result = breedDataDog[row]
            }
            else {
                result =  breedDataCat[row]
            }
            return result
        case 1:
            var resultArray = color
            var result = resultArray[row]
            return result
        
        default:
            break
        }
        return nil
        
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag{
        case 0:
            if selectedTypeAnimal == 0 {
                breedOfAnimal.text = breedDataDog[row]
            }
            else {
                breedOfAnimal.text = breedDataCat[row]
            }
        case 1:
            var resultArray = color
            colorOfAnimal.text = resultArray[row]
      
        default:
            break
            
        }
    }
    
    
    
    
    //////Загрузка фото
     let imagePicker = UIImagePickerController()
     var selectedButtonForImage = 1
    
    @IBAction func addImage(_ sender: UIButton) {
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        selectedButtonForImage = sender.tag
        imagePicker.allowsEditing = true
        present(imagePicker,animated: true)
        
     }
    
    
    
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        var data = Data()
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpeg"
    
        if let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage{
            
            data = image.jpegData(compressionQuality:0.75)!
            let imgRef = Storage.storage().reference().child("all-images").child(String(Int.random(in: 0...1000_000_000)) + ".jpeg")
            var result:String = imgRef.fullPath
            let parsed = result.replacingOccurrences(of: "all-images/", with: "")
            print("parsed - \(parsed)")
            
               self.images.append(parsed)
            _ = imgRef.putData(data, metadata: metaData, completion: { (metadata , error) in
               
                
               
                 imgRef.downloadURL(completion: { (url, error) in
                    if error != nil {
                        print(error!.localizedDescription)
                        return
                    }
                     let imageUrl = url?.absoluteString ?? ""
                        print(imageUrl)
                       // self.images.append(imageUrl)
                    print("images \(self.images)")
                    
                    })
               
        })
        
          switch selectedButtonForImage{
            case 1:
                imageView1.isHidden = false
                addImageButton1.isHidden = true
                imageView1.image  = image
            case 2:
                imageView2.isHidden = false
                addImageButton2.isHidden = true
                imageView2.image  = image
            case 3:
                imageView3.isHidden = false
                addImageButton3.isHidden = true
                imageView3.image  = image
            case 4:
                imageView4.isHidden = false
                addImageButton4.isHidden = true
                imageView4.image  = image
            default:
                break
            }
        } 
          self.dismiss(animated: true, completion: nil)
    }
 
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        textView.textColor = UIColor.black
        textView.text = ""
    }


    
  
  lazy var  userID : String = (Auth.auth().currentUser?.uid)!
    //MARK: - Добавить проверку!
    
    @IBAction func addPublication() {///Добавляем в бд новую публикацию
        
        func check1()->String{
            let s = selectedGenderAnimal == 0 ? "Кобель" : "Сука"
            return s
        }
        func check2()->String{
            let s = selectedTypeAnimal == 0 ? "Собака" : "Кошка"
            return s
        }
        //genderAnimalString = typeAnimalOutletSC.selectedSegmentIndex == 0 ? "Кобель" : "Сука"
       // typeAnimalString = typeAnimalOutletSC.selectedSegmentIndex == 0 ? "Собака" : "Кошка"
      
        if nameOfAnimal.text != "" && breedOfAnimal.text != "" && colorOfAnimal.text != "" && ageOfAnimal.text != ""  {
    
        let ref = Database.database().reference(withPath: "publications")
            ref.child("\(animalsArray.count)").updateChildValues(["Animal":check2(), "Name": self.nameOfAnimal.text!, "Sex":check1(), "Breed":self.breedOfAnimal.text!, "Color":self.colorOfAnimal.text!, "Age":self.ageOfAnimal.text!, "Description":self.descriptionOfAnimal.text!, "uID":String(userID), "image0":images[0], "image1":images[1], "image2":images[2], "image3":images[3]])
            
           ref.child("\(animalsArray.count)").child("photos").updateChildValues(
             ["0":images[0], "1":images[1], "2":images[2] , "3":images[3]]
            )
            
           performSegue(withIdentifier: "tabSeg", sender: nil)
           
        }
        else { //если поля заполнены
            let alert = UIAlertController(title: "Ошбика", message: "Заполните все поля", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "ок", style: .default, handler: nil)
        }
        
    }
  
////////Загрузка документа
    /* @IBAction func importDocument(_ sender: UIButton) {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["com.adobe.pdf"], in: .import)
        documentPicker.delegate = self
       present(documentPicker,animated: true,completion: nil)
        
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
         let selectedFileURL = url
        do{
         let dir = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        }
        catch{
            print("error")
        }
        
       
         //let sandBoxFileURL =
    } */
    
    
    
}
/*var name:String
 var gender:String
 var breed:String
 var color:String
 var region:String
 var city:String
 //var rating:String
 var age:String
 var description:String
 //var imageArray:[UIImage]
 var imageAnimal:UIImage
 */
    


