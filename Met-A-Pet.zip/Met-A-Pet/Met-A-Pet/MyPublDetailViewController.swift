//
//  MyPublDetailViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/11/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage

class MyPublDetailViewController: UIViewController {
    @IBOutlet weak var detailImage0: UIImageView!
    @IBOutlet weak var detailImage1: UIImageView!
    
    @IBOutlet weak var detailImage2: UIImageView!
    @IBOutlet weak var detailImage3: UIImageView!
    @IBOutlet weak var nameTxt: UILabel!
    
    @IBOutlet weak var breedTxt: UILabel!
    
    @IBOutlet weak var descriptionTxt: UILabel!
    @IBOutlet weak var ageTxt: UILabel!
    @IBOutlet weak var genderTxt: UILabel!
    @IBOutlet weak var colotTxt: UILabel!
    
    func getImage(imageADD:String,im:UIImageView){
        let strRef = Storage.storage().reference()
        var full = strRef.child("all-images/"+imageADD)
        full.getData(maxSize:  (1 * 1024 * 1024)) {(data, error) in
            if let _error = error{
                print(_error)
                
            } else {
                if let _data  = data {
                    let myImage:UIImage! = UIImage(data: _data)
                    im.image = myImage
                }
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTxt.text = nameMy
        ageTxt.text = ageMy
        descriptionTxt.text = descrMy
        genderTxt.text = genderMy
        breedTxt.text  = breedMy
        colotTxt.text = colorMy
         getImage(imageADD: imageMy0,im: detailImage0)
        getImage(imageADD: imageMy1,im: detailImage1)
       getImage(imageADD: imageMy2,im: detailImage2)
         getImage(imageADD: imageMy3,im: detailImage3)

        
    }
    



}
