//
//  PDFViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/5/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import WebKit

class PDFViewController: UIViewController,WKNavigationDelegate {
    
    @IBOutlet weak var pdfWEbView: WKWebView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pdfWEbView.navigationDelegate = self
        
        if let filename = title{
            openPdf(filename: filename)
        }
        

       
    }
    
    private func openPdf(filename:String){
        if let filepath = Bundle.main.url(forResource: filename, withExtension: "pdf"){
            let request = URLRequest(url: filepath)
            pdfWEbView.load(request)
        }else{
            print("Нет такого файла пдф")
        }
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        activityIndicator.stopAnimating()
    }
    

   

}
