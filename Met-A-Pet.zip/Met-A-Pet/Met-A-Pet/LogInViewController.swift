//
//  LogInViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/2/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import Firebase

class LogInViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.email.delegate = self
        self.password.delegate = self
        
    }
    
    @IBAction func enterButtonLogIn() {
       
        if email.text != "" && password.text != ""{
            if validateEmail(enteredEmail: email.text!) == true {
                 print("validated Email")
                Auth.auth().signIn(withEmail: self.email.text!, password: self.password.text!) { result,error in
                    if error == nil{
                        if let result = result {
                            print("need to go")
                            let pvc = self.storyboard?.instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
                            self.present(pvc, animated: true, completion: nil)
                        }
                    }
                    else {
                        print("error in sign in ")
                    }
                }
            }
        }
        else{
            let alert = UIAlertController(title: "Ошибка", message: "Заполните пожалуйста все поля", preferredStyle: .alert)
            let ok = UIAlertAction(title: "ок", style: .default, handler: {
                action in
                let emptyTextField: UITextField =  self.email.text == "" ? self.email : self.password
                emptyTextField.becomeFirstResponder()
            })
            alert.addAction(ok)
            self.present(alert, animated: true)
           
        }
        
    }
    
    @IBAction func registrationButtonOnLogIn() {
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == email{
            password.becomeFirstResponder()
        }
        else{
            password.resignFirstResponder()
        }
        return true
    }
    
    func validateEmail(enteredEmail:String) -> Bool {
        
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: enteredEmail)
    }

 

}
