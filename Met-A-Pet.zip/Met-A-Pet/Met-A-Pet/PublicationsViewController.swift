//
//  PublicationsViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/3/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit

class PublicationsViewController: UITabBarController {
   // @IBOutlet weak var typeAnimalSegmentedControl: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
//typeAnimalSegmentedControl.font
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
