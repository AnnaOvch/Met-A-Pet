//
//  FilterViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/4/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import QuartzCore
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth
import Firebase

class FilterViewController: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate  {
    
    
    
    var selectedTypeAnimal = 0 // по дефолту собака
    
    var selectedGender = 0 //по дефолту кобель
    
    var selectedIndexOfBreed = 0
    
    var selectIndexOfColor = 0
    
    var selectedIndexOfRegion = 0
    
    
    let regionsData = [String](arrayLiteral: "Харьковская обл.", "Киевская обл.", "Одесская обл.", "Львовская обл.")
 
    let cityData: [[String]] = [["Харьков","Полтава","Чугуев","Мерефа"], ["Киев","Город возле Киева"],["Одесса","Город возле Одессы"],["Львов","Карпаты","Трусковец","Хуйня какая-то"]]

    @IBOutlet weak var genderOutletSC: UISegmentedControl!
    @IBOutlet weak var typeAnimalOutletSC: UISegmentedControl!
    @IBOutlet weak var breedVariants: UITextField!
    @IBOutlet weak var colorVariants: UITextField!
    @IBOutlet weak var regionSearch: UITextField!
    @IBOutlet weak var citySearch: UITextField!
    @IBOutlet weak var buttonSearch: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      

        
        
        breedVariants.delegate = self
        colorVariants.delegate = self
        regionSearch.delegate = self
        citySearch.delegate = self
        
        
        thePicker.tag = 0
        thePickerColor.tag = 1
        thePickerRegion.tag = 2
        thePickerCity.tag = 3
        thePicker.delegate = self
        thePickerColor.delegate = self
        thePickerCity.delegate = self
        thePickerRegion.delegate = self
        
        
        
        //////все для дизайна текстфилад и СК
        
        let font = UIFont.systemFont(ofSize: 20)
        typeAnimalOutletSC.setTitleTextAttributes([NSAttributedString.Key.font: font], for: .normal)
        genderOutletSC.setTitleTextAttributes([NSAttributedString.Key.font: font], for: .normal)
        breedVariants.attributedPlaceholder = NSAttributedString(string: "Выберите породу",
                                                               attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
        colorVariants.attributedPlaceholder = NSAttributedString(string: "Выберите окрас",
                                                                 attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
        citySearch.attributedPlaceholder = NSAttributedString(string: "Выберите город",
                                                              attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
        regionSearch.attributedPlaceholder = NSAttributedString(string: "Выберите область",
                                                              attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
        
       // borderтекстфилдов
        let myColor = UIColor.init(red: 0.0, green: 122.0/255.0, blue: 1.0 , alpha: 1.0)
        
        breedVariants.layer.borderColor = myColor.cgColor
        colorVariants.layer.borderColor = myColor.cgColor
        breedVariants.layer.borderWidth = 1.0
        colorVariants.layer.borderWidth = 1.0
        citySearch.layer.borderColor = myColor.cgColor
        regionSearch.layer.borderColor = myColor.cgColor
        citySearch.layer.borderWidth = 1.0
        regionSearch.layer.borderWidth = 1.0
        
        
        
        /// породы
        breedVariants.inputView = thePicker
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(self.doneClick))
        let cancelButton = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(self.cancelClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        breedVariants.inputAccessoryView = toolBar
        
        //окрасы
        colorVariants.inputView = thePickerColor
        let toolBar1 = UIToolbar()
        toolBar1.barStyle = .default
        toolBar1.sizeToFit()
        let doneButton1 = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(self.doneClick1))
        let cancelButton1 = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(self.cancelClick1))
        let spaceButton1 = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar1.setItems([cancelButton1, spaceButton1, doneButton1], animated: false)
        colorVariants.inputAccessoryView = toolBar1
        
        //для регионов
    regionSearch.inputView = thePickerRegion
        let toolBarRegion = UIToolbar()
        toolBarRegion.barStyle = .default
        toolBarRegion.sizeToFit()
        let doneButtonRegion = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(self.doneClickRegion))
        let cancelButtonRegion = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(self.cancelClickRegion))
        let spaceButtonRegion = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBarRegion.setItems([cancelButtonRegion, spaceButtonRegion, doneButtonRegion], animated: false)
        regionSearch.inputAccessoryView = toolBarRegion
        
        //для городов
        
        citySearch.inputView = thePickerCity
        let toolBarCity = UIToolbar()
        toolBarCity.barStyle = .default
        toolBarCity.sizeToFit()
        let doneButtonCity = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(self.doneClickCity))
        let cancelButtonCity = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(self.cancelClickCity))
        let spaceButtonCity = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBarCity.setItems([cancelButtonCity, spaceButtonCity, doneButtonCity], animated: false)
        citySearch.inputAccessoryView = toolBarCity
        
     }
    
    let thePicker = UIPickerView() // для пород
    let thePickerColor = UIPickerView() // для окрасов
    let thePickerRegion = UIPickerView()//для регионов
    let thePickerCity = UIPickerView() // для городов
    
   @objc func doneClick() {
   
        let indexPath = thePicker.selectedRow(inComponent: 0)
        selectedIndexOfBreed = indexPath
        breedVariants.text = selectedTypeAnimal == 0 ? breedDataDog[indexPath] : breedDataCat[indexPath]
        self.view.endEditing(true)
    
        
        
    }
    @objc func cancelClick() {
        print("fuck")
        breedVariants.text = ""
        //colorVariants.text = ""
        self.view.endEditing(true)
    }
    @objc func doneClick1() {
        
        let indexPath = thePickerColor.selectedRow(inComponent: 0)
        //let resultArray =  selectedTypeAnimal == 0 ? colorDog : colorCat
        colorVariants.text = color[indexPath]
        self.view.endEditing(true)
        
        
    }
    @objc func cancelClick1() {
        colorVariants.text = ""
        self.view.endEditing(true)
    }
    @objc func doneClickRegion() {
        
        let indexPath = thePickerRegion.selectedRow(inComponent: 0)
        selectedIndexOfRegion = indexPath
        regionSearch.text = regionsData[indexPath]
        citySearch.text = ""
        self.view.endEditing(true)
    }
    @objc func cancelClickRegion() {
        regionSearch.text = ""
        citySearch.text = ""
        self.view.endEditing(true)
    }
    @objc func doneClickCity() {
        
        let indexPath = thePickerCity.selectedRow(inComponent: 0)
        citySearch.text = cityData[selectedIndexOfRegion][indexPath]
        self.view.endEditing(true)
        
        
    }
    @objc func cancelClickCity() {
        citySearch.text = ""
        self.view.endEditing(true)
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag {
        case 0:
            var result = selectedTypeAnimal == 0 ? breedDataDog.count : breedDataCat.count
            return result
        case 1:
            
             var result = color.count
             return result
        case 2:
            return regionsData.count
        case 3:
             return cityData[selectedIndexOfRegion].count
        default:
            break
        }
        return 0
    }
    
    
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        switch pickerView.tag {
        case 0:
            var result:String
            if selectedTypeAnimal == 0 {
                result = breedDataDog[row]
            }
            else {
                result =  breedDataCat[row]
            }
            return result
        case 1:
            var resultArray = color
            var result = resultArray[row]
            return result
        case 2:
            return regionsData[row]
        case 3:
             return cityData[selectedIndexOfRegion][row]
         default:
            break
        }
        return nil
        
        
       
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag{
        case 0:
            if selectedTypeAnimal == 0 {
                breedVariants.text = breedDataDog[row]
            }
            else {
                breedVariants.text = breedDataCat[row]
            }
        case 1:
            var resultArray = color
            colorVariants.text = resultArray[row]
        case 2:
            regionSearch.text = regionsData[row]
        case 3:
            citySearch.text = cityData[selectedIndexOfRegion][row]
        default:
            break
            
        }
    }
    
    
    
       @IBAction func typeAnimalActionSC(_ sender: UISegmentedControl) {
        
        selectedTypeAnimal = typeAnimalOutletSC.selectedSegmentIndex
        breedVariants.text = ""
        colorVariants.text = ""
        
        
    }
    
       @IBAction func genderActionSC(_ sender: UISegmentedControl) {
        
        selectedGender = genderOutletSC.selectedSegmentIndex
        if genderOutletSC.selectedSegmentIndex == 1{
            print("suka")
        }else{
            print("kobel")
        }
        
    }
    
    @IBAction func searchNear(_ sender: UISwitch) {
        let yaxis = 91.0
        if sender.isOn == false{ // выключен
            citySearch.isHidden = false
            regionSearch.isHidden = false
            buttonSearch.center.y = 640.0
            buttonOn = false
        }
        else { //включен
            buttonSearch.center.y = 545.0
            citySearch.isHidden = true
            regionSearch.isHidden = true
            buttonOn = true
        }
        
    }
    
    @IBAction func searchButtonAction() {
        
        /*  Database.database().reference().child("publications").queryOrdered(byChild: "type").queryEqual(toValue: "Собака").observeSingleEvent(of: .value, with: { (snapshot) in
            
            
            guard let dictionary = snapshot.value as? [String:Any] else {return}
            
            dictionary.forEach({ (key , value) in
                
                print("Key \(key), value \(value) ")
                
                
            })
            
            
            
        }) { (Error) in
            
            print("Failed to fetch: ", Error)
            
        } */
        
        selectedTypeForResult = self.selectedTypeAnimal == 0 ? "Собака" : "Кошка"
        selectedGenderForReult = self.selectedGender == 0 ? "Кобель" : "Сука"
        selectedBreedForResult = self.breedVariants.text ?? ""
        selectedColorForResult = self.colorVariants.text ?? ""
        selectedCityForResult = self.citySearch.text ?? ""
        selectedRegionForResult = self.regionSearch.text ?? ""
    
             let svc = self.storyboard?.instantiateViewController(withIdentifier: "NavFromFilterViewController") as! NavFromFilterViewController
            self.present(svc, animated: true, completion: nil)
            
        
    }
    
}
