//
//  UserViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/11/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseDatabase

class UserViewController: UIViewController {
    var indicator = true // обычное состояние сохраненное

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fill()
        //myName.text =

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var myName: UITextField!
    
    @IBOutlet weak var mySurname: UITextField!
    
    @IBOutlet weak var myArea: UITextField!
    
  //   @IBOutlet weak var myEmail: UITextField!
    @IBOutlet weak var myCity: UITextField!
    
    @IBOutlet weak var myPhone: UITextField!
    
    @IBAction func buttonChangeSave(_ sender: UIButton) {
        if  indicator == true{
            sender.setTitle("СОХРАНИТЬ", for: .normal)
            myName.isEnabled = true
            mySurname.isEnabled = true
            myArea.isEnabled = true
            //myEmail.isEnabled = true
            myPhone.isEnabled = true
        }
        else {
            sender.setTitle("ИЗМЕНИТЬ", for: .normal)
            myName.isEnabled = false
            mySurname.isEnabled = false
            myArea.isEnabled = false
           // myEmail.isEnabled = false
            myPhone.isEnabled = false
            
            let ref = Database.database().reference(withPath: "users")
            ref.child(Auth.auth().currentUser!.uid).updateChildValues(["userName":self.myName.text,"userSurname":self.mySurname.text,"userArea":self.myArea.text,"userCity":self.myCity.text,"userPhone":self.myPhone.text])
            print("done")
        }
        indicator =  !indicator
        
    }
    @IBAction func logOut(_ sender: UIButton) {
        do{
            try Auth.auth().signOut()
        }
        catch {
            print("error")
        }
    }
    
    func fill(){
        let id = String(Auth.auth().currentUser!.uid)
        
        let ref = Database.database().reference(withPath: "users")
        ref.child(id).observeSingleEvent(of: .value, with: ({ (snapshot) in
            
            if snapshot.exists(){
                
                let citySnVal = snapshot.value as! [String:AnyObject]
                
                let city = citySnVal["userCity"] as! String
                self.myCity.text = city
                
                
                let region = citySnVal["userArea"] as! String
                self.myArea.text = region
                
                let name = citySnVal["userName"] as! String
                self.myName.text = name
                
                let number = citySnVal["userPhone"] as! String
                self.myPhone.text = number
                
                let surn = citySnVal["userSurname"] as! String
                self.mySurname.text = surn
                
                
            }
            else {
                print("noooooo")
            }
        }))
    }
    
}
