//
//  SearchTableViewCell.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/5/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage



class SearchTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameResultSearch: UILabel!
    @IBOutlet weak var genderResultSearch: UILabel!
    @IBOutlet weak var breedResultSearch: UILabel!
    @IBOutlet weak var cityResultSearch: UILabel!
    @IBOutlet weak var imageResultSearch: UIImageView!
    
    func set(animal:Animal){
       //let imgRef = Storage.storage().reference(withPath: (animal.imagesAnimal?[0])!)
       // print("imgRef \(imgRef)")
       print("settt")
        let refU = Database.database().reference(withPath: "users")
        refU.child(animal.currentUser).observeSingleEvent(of:.value) {
            (snapshot) in
            print(animal.currentUser)
            print(snapshot.children)
            
            if snapshot.exists(){ 
                print("exists!!!!!!!!!!!")
                let citySnVal = snapshot.value as! [String:AnyObject]
                let city = citySnVal["userCity"] as! String
                cityAD = city
                print(cityAD)
                
                self.cityResultSearch.text = city
                let region = citySnVal["userArea"] as! String
                regionAD = region
                let name = citySnVal["userName"] as! String
                nameOwnerAD = name
                let number = citySnVal["userPhone"] as! String
                numberOwnerAD = number
            }
            else {
                print("noooooo")
            }
            /*for child in snapshot.children{
                print(child)
                let citySnVal = snapshot.value as! [String:AnyObject]
                let city = citySnVal["userCity"] as! String
                self.cityResultSearch.text = city
                print("cityResult" + self.cityResultSearch.text!)
            }*/
            // let citySnVal = snapshot.value as? [String:AnyObject]
            // let city = value["userCity"] as! String
            //self.cityResultSearch.text = city
            
            
        }
        
       
        
    
        nameResultSearch.text = animal.name
        genderResultSearch.text = animal.gender
        breedResultSearch.text = animal.breed
        
        
        let strRef = Storage.storage().reference()
        let full = strRef.child("all-images/"+animal.imageAnimal0)
        print(full)
        full.getData(maxSize:  (1 * 1024 * 1024)) {(data, error) in
            if let _error = error{
                print(_error)
                
            } else {
                if let _data  = data {
                    let myImage:UIImage! = UIImage(data: _data)
                    self.imageResultSearch.image = myImage
                }
            }
            
        }
        
   
    
}
}
