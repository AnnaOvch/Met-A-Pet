//
//  StoraageViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/9/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
class StoraageViewController: UIViewController {
    
    @IBOutlet weak var imageStorage: UIImageView!
    
   // let imgRef = Storage.storage().reference(forURL:  "https://firebasestorage.googleapis.com/v0/b/met-a-pet-812ca.appspot.com/o/images%2F934003779?alt=media&token=adfdec6c-b34d-4349-ab59-33d92483dc44")
   
   
    override func viewDidLoad() {
        super.viewDidLoad()
       
       
        
       
    }
    
    @IBAction func tap(_ sender: UIButton) {
        let ref = Storage.storage().reference()
         var imgref = ref.child("images/205598932")

        imgref.getData(maxSize:  (1 * 1024 * 1024)) {(data, error) in
            if let _error = error{
                print(_error)
                
            } else {
                if let _data  = data {
                    let myImage:UIImage! = UIImage(data: _data)
                    self.imageStorage.image = myImage
                }
            }
            
        }
    }
    

}

