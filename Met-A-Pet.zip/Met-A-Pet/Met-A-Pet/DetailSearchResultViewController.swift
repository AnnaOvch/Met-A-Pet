//
//  DetailSearchResultViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/5/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseDatabase




class DetailSearchResultViewController: UIViewController,UIPickerViewDelegate {
   
    
    @IBOutlet weak var imageAnimalDetail: UIImageView!
    @IBOutlet weak var breedAnimalDetail: UILabel!
    @IBOutlet weak var colorAnimalDetail: UILabel!
    @IBOutlet weak var ageAnimalDetail: UILabel!
    @IBOutlet weak var genderAnimalDetail: UILabel!
    @IBOutlet weak var nameAnimalDetail: UILabel!
    @IBOutlet weak var regionAnimalDetail: UILabel!
    @IBOutlet weak var cityAnimalDetail: UILabel!
    @IBOutlet weak var descriptionAnimalDetail: UILabel!
    @IBOutlet weak var typeDocumentAnimalDetail: UITextField!
    @IBOutlet weak var nameOwnerAnimalDetail: UILabel!
    
    var counter = 0
    var counterBack = 0
    
   
    
    func getImage(imageADD:String){
        let strRef = Storage.storage().reference()
         var full = strRef.child("all-images/"+imageADD)
        full.getData(maxSize:  (1 * 1024 * 1024)) {(data, error) in
            if let _error = error{
                print(_error)
                
            } else {
                if let _data  = data {
                    let myImage:UIImage! = UIImage(data: _data)
                    self.imageAnimalDetail.image = myImage
                }
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getImage(imageADD: imageAD)
        breedAnimalDetail.text = breedAD
        colorAnimalDetail.text = colorAD
        ageAnimalDetail.text = ageAD
        genderAnimalDetail.text = genderAD
        nameAnimalDetail.text = nameAD
        regionAnimalDetail.text = regionAD
        cityAnimalDetail.text = cityAD
        descriptionAnimalDetail.text = descriptionAD
        nameOwnerAnimalDetail.text = nameOwnerAD
        //setPicker() // Picker for documentation
        //pickerDocument.delegate = self
        //typeDocumentAnimalDetail.dataSourse = self
        
        
    
    }
    
    @IBAction func nextImage() {
        print("next")
        
        func nextPicture(img: String){
            
            
            let strRef = Storage.storage().reference()
            var full = strRef.child("all-images/"+img)
        full.getData(maxSize:  (1 * 1024 * 1024)) {(data, error) in
            if let _error = error{
                print(_error)
                
            } else {
                if let _data  = data {
                    let myImage:UIImage! = UIImage(data: _data)
                    self.imageAnimalDetail.image = myImage
                }
            }
            
            }
      }
        
        
        if counter == 0 {
            nextPicture(img: imageAD1)
            counter = 1
            counterBack = 1
        }
        else if counter == 1 {
            nextPicture(img: imageAD2)
            counter = 2
            counterBack = 2
        }
        else if counter == 2 {
            nextPicture(img: imageAD3)
            counter = 3
            counterBack = 3
        }
        else if counter == 3 {
            nextPicture(img: imageAD)
            counter = 0
            counterBack = 0
        }
        
        
    }
    @IBAction func previousImage() {
        
        func nextPicture(img: String){
            
            
            let strRef = Storage.storage().reference()
            var full = strRef.child("all-images/"+img)
            full.getData(maxSize:  (1 * 1024 * 1024)) {(data, error) in
                if let _error = error{
                    print(_error)
                    
                } else {
                    if let _data  = data {
                        let myImage:UIImage! = UIImage(data: _data)
                        self.imageAnimalDetail.image = myImage
                    }
                }
                
            }
        }
        
        
        if counter == 0 {
            nextPicture(img: imageAD3)
            counter = 3
            counterBack = 3
        }
        else if counter == 1 {
            nextPicture(img: imageAD)
            counter = 0
            counterBack = 0
        }
        else if counter == 2 {
            nextPicture(img: imageAD1)
            counter = 1
            counterBack = 1
        }
        else if counter == 3 {
            nextPicture(img: imageAD2)
            counter = 2
            counterBack = 2
        }
        
    }
    
  /*func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }*/
    
   /* func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrayDoc.count
    }
    
    */
    @IBAction func openPDF() {
        performSegue(withIdentifier: "pdfSegue", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if  let pdfVC = segue.destination as? PDFViewController{
            pdfVC.title = "sample"
        }else{
            print("can not prepare")
        }
    }
    
    @IBAction func infoOwnerButton() {
    }
    
    
    //MARK-Picker for doc
    
    //let pickerDocument = UIPickerView()
    //let arrayDoc = ["Паспорт","Прививки"]
    
    /*func setPicker(){
        typeDocumentAnimalDetail.inputView = pickerDocument
        let toolBarDocument = UIToolbar()
        toolBarDocument.barStyle = .default
        toolBarDocument.sizeToFit()
        let doneButtonDocument = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(self.doneClick))
        let cancelButtonDocument = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(self.cancelClick))
        let spaceButtonDocument = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBarDocument.setItems([cancelButtonDocument, spaceButtonDocument, doneButtonDocument], animated: false)
        typeDocumentAnimalDetail.inputAccessoryView = toolBarDocument
        
    }*/
   /* @objc func doneClick() {
        let indexPath = pickerDocument.selectedRow(inComponent: 0)
        typeDocumentAnimalDetail.text = arrayDoc[indexPath]
        self.view.endEditing(true)
        
        
        
    }
    @objc func cancelClick() {
        typeDocumentAnimalDetail.text = ""
        self.view.endEditing(true)
    }
  */
    func makePhoneCall(phoneNumber: String) {
        if let phoneURL = NSURL(string: ("tel://" + phoneNumber)) {
            let alert = UIAlertController(title: ("Позвонить " + phoneNumber + "?"), message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Да", style: .default, handler: { (action) in
                UIApplication.shared.openURL(phoneURL as URL)
            }))
            
            alert.addAction(UIAlertAction(title: "Отмена", style: .cancel, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
    }
    @IBAction func callOwnerButton(_ sender: UIButton) {
        makePhoneCall(phoneNumber: numberOwnerAD)
        //let alert = UIAlertController(title: "", message: "<#T##String?#>", preferredStyle: <#T##UIAlertController.Style#>)
    }
    
}
