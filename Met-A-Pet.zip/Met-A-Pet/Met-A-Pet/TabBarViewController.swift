//
//  TabBarViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/4/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
//нужен для перехода с логина
class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

   

}
