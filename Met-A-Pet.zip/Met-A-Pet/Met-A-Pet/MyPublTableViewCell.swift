//
//  MyPublTableViewCell.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/11/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseStorage

class MyPublTableViewCell: UITableViewCell {
    @IBOutlet weak var genderMyPubl: UILabel!
    
    @IBOutlet weak var breedMyPubl: UILabel!
    @IBOutlet weak var nameMyPubl: UILabel!
    @IBOutlet weak var imageMyPubl: UIImageView!
    
    
    
    
    func set(animal:Animal){
        
        print("settt")
       /* let refU = Database.database().reference(withPath: "users")
        refU.child(String(animal.currentUser)).observeSingleEvent(of:.value) {
            (snapshot) in
            if snapshot.exists(){
                print("exists")
                let citySnVal = snapshot.value as! [String:AnyObject]
                let city = citySnVal["userCity"] as! String
                
                let name = citySnVal["userName"] as! String
                self.nameMyPubl.text = name
                
                let number = citySnVal["userPhone"] as! String
                numberOwnerAD = number
            }
            else {
                print("noooooo")
            }
            
            
            
        }*/
        
        
        
        
        nameMyPubl.text = animal.name
        genderMyPubl.text = animal.gender
        breedMyPubl.text = animal.breed
       
        
        let strRef = Storage.storage().reference()
        let full = strRef.child("all-images/"+animal.imageAnimal0)
        print(full)
        full.getData(maxSize:  (1 * 1024 * 1024)) {(data, error) in
            if let _error = error{
                print(_error)
                
            } else {
                if let _data  = data {
                    let myImage:UIImage! = UIImage(data: _data)
                    self.imageMyPubl.image = myImage
                }
            }
            
        }
        
       
        
    }

}
