//
//  RegistrationViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/2/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase
import Firebase

class RegistrationViewController: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate {
   
    
  
    
    @IBOutlet weak var birthdayDate: UITextField!
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var surname: UITextField!
    
    @IBOutlet weak var region: UITextField!
    
    @IBOutlet weak var city: UITextField!
    
    @IBOutlet weak var mobile: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var confirmPassword: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        birthdayDate.delegate = self
        name.delegate = self
        surname.delegate = self
        region.delegate = self
        city.delegate = self
        mobile.delegate = self
        email.delegate = self
        password.delegate = self
//        confirmPassword.delegate = self
        
        
        showDatePicker()//дата
        
        thePickerCity.delegate = self
        thePickerCity.dataSource = self
        thePicker.delegate = self // список обл
        thePicker.dataSource = self
        thePickerCity.tag = 2
        thePicker.tag = 1
        
       
        
        region.inputView = thePicker//список обл
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(RegistrationViewController.doneClick))
        let cancelButton = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(RegistrationViewController.cancelClick))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        region.inputAccessoryView = toolBar
        
        
        city.inputView = thePickerCity
        let toolBar1 = UIToolbar()
        toolBar1.barStyle = .default
        toolBar1.sizeToFit()
        let doneButton1 = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(RegistrationViewController.doneClick1))
        let cancelButton1 = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(RegistrationViewController.cancelClick1))
        let spaceButton1 = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolBar1.setItems([cancelButton1, spaceButton1, doneButton1], animated: false)
        city.inputAccessoryView = toolBar1
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        
      
    }
    
    //let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
    
    //.addGestureRecognizer(tap)
    
    
    // function which is triggered when handleTap is called
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        print("Hello World")
        self.view.endEditing(true)
    }
    
    
    //////выпадающий список областей
    let thePicker = UIPickerView()
    var selectedIndexOfRegion = 0
   
    
    @objc func doneClick() {
        let indexPath = thePicker.selectedRow(inComponent: 0)
        selectedIndexOfRegion = indexPath
        region.text = regionsData[indexPath]
        city.text = ""
        
        self.view.endEditing(true)
        
        
    }
    @objc func cancelClick() {
        region.text = ""
    
        self.view.endEditing(true)
    }
    
    let regionsData = [String](arrayLiteral: "Харьковская обл.", "Киевская обл.", "Одесская обл.", "Львовская обл.","Днепропетровская обл.","Сумская обл.")
   
   ////////////выпадающий список городов
    
    let cityData: [[String]] = [["Харьков","Полтава","Чугуев","Мерефа"], ["Киев","Борисполь","Бровары","Васильков"],["Одесса","Южный","Черноморск","Измаил","Подольск"],["Львов","Драгобыч","Трусковец","Борислав","Броды"],["Кривой Рог","Каменское","Днепр"],["Суммы","Охтырка"]]
    
    var thePickerCity = UIPickerView()
   
    
    @objc func doneClick1(){
    
        let indexPath = thePickerCity.selectedRow(inComponent: 0)
        city.text = cityData[selectedIndexOfRegion][indexPath]
        self.view.endEditing(true)
    
    }
    
    @objc func cancelClick1(){
        city.text = ""
         self.view.endEditing(true)
        
        //city.resignFirstResponder()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
       return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag{
        case 1:
            return regionsData.count
        case 2:
            
            return cityData[selectedIndexOfRegion].count
        default:
            break
        }
        return 0
        
        
    }
    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag{
        case 1:
            return regionsData[row]
        case 2:
            return cityData[selectedIndexOfRegion][row]
        default:
            break
        }
        return nil
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch pickerView.tag{
        case 1:
            region.text = regionsData[row]
            //selectedIndexOfRegion = row
        case 2:
            city.text = cityData[selectedIndexOfRegion][row]
        default:
            break
        }
    }

  
    
    
    
    ///выбор даты
    
    let datePicker = UIDatePicker()
    
    func showDatePicker(){
        //Formate Date
        datePicker.datePickerMode = .date
        datePicker.locale = Locale(identifier: "ru")
        
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Готово", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        
        birthdayDate.inputAccessoryView = toolbar
        birthdayDate.inputView = datePicker
        
    }
    
    @objc func donedatePicker(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        birthdayDate.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        birthdayDate.text = ""
        self.view.endEditing(true)
        
    }
  ////////////////password
    
    
     func textFieldShouldReturn(textfield: UITextField!) -> Bool{
        
      self.view.endEditing(true)
        return true
    }
    
  
   
    @IBAction func doneRegistrationAction() {
       
        Auth.auth().createUser(withEmail: (email.text ?? ""), password: (password.text ?? "")) { (result, error) in
            if let _eror = error {
                print("ERRORRRRR")
                print(_eror.localizedDescription )
                let alert = UIAlertController(title: "Ошибка", message: "Проверьте подключение к интернету", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "ок", style:.default, handler: nil))
            }else{
                //print(result!.user.uid)
                let ref = Database.database().reference(withPath: "users")
                ref.child(result!.user.uid).updateChildValues(["userName":self.name.text,"userMail":self.email.text,"userBirth":self.birthdayDate.text,"userSurname":self.surname.text,"userArea":self.region.text,"userCity":self.city.text,"userPhone":self.mobile.text])
                 print("done")
                let sb = UIStoryboard(name: "Main", bundle: nil)
                let tbv = sb.instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
                self.present(tbv,animated: true)
            }
        }
    
}
    
   /* @IBAction func logOutAction() {
        do{
            try Auth.auth().signOut()
        }
        catch {
            print("error")
        }
    }*/
    
}
