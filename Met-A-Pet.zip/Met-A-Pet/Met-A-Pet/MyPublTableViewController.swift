//
//  MyPublTableViewController.swift
//  Met-A-Pet
//
//  Created by Анна Овчинникова  on 6/11/19.
//  Copyright © 2019 Анна Овчинникова . All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

var nameMy = ""
var genderMy = ""
var colorMy = ""
var descrMy = ""
var breedMy = ""
var ageMy = ""
var imageMy0 = ""
var imageMy1 = ""
var imageMy2 = ""
var imageMy3 = ""
class MyPublTableViewController: UITableViewController {
 var myArrayAnimal:[Animal] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let curUserForMYPubl = Auth.auth().currentUser?.uid
        Database.database().reference().child("publications").queryOrdered(byChild: "uID").queryEqual(toValue: String(curUserForMYPubl!)).observeSingleEvent(of: .value, with: { (snapshot) -> Void in
            
            var newArrayAnimals = [Animal]()
            
            for child in snapshot.children { // children of "publications"
                
                if let snapshot = child as? DataSnapshot {
                    
                    if  let animal = Animal(snapshot: snapshot) {
                        
                        newArrayAnimals.append(animal)
                        
                    }
                    else {
                        print("not animal")
                    }
                }
                else {
                    print("not snapshot")
                }
            }
            
            self.myArrayAnimal = newArrayAnimals
            print(self.myArrayAnimal)
            self.tableView.reloadData()
        })
    }
    
       
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return myArrayAnimal.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myPublId", for: indexPath) as! MyPublTableViewCell
        cell.layer.borderWidth = 0.5
        let borderColor: UIColor = .black
        cell.layer.borderColor = borderColor.cgColor
        
        cell.set(animal:myArrayAnimal[indexPath.row])
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
         nameMy = myArrayAnimal[indexPath.row].name
         colorMy = myArrayAnimal[indexPath.row].color
         descrMy = myArrayAnimal[indexPath.row].description
         breedMy = myArrayAnimal[indexPath.row].breed
         ageMy = myArrayAnimal[indexPath.row].age
         genderMy = myArrayAnimal[indexPath.row].gender
         imageMy0 = myArrayAnimal[indexPath.row].imageAnimal0
         imageMy1 = myArrayAnimal[indexPath.row].imageAnimal1
         imageMy2 = myArrayAnimal[indexPath.row].imageAnimal2
         imageMy3 = myArrayAnimal[indexPath.row].imageAnimal3
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
